//Portal module with any external function or algorithm relatively to the applications
if(!Application)
	 var Application ={};
(function(app){

 app.init = (function(portal , callback){

   var timer = new Application.utils.Timer(0);
   timer.run((function(portal, callback){
   //initialised the portal
   //get the current client;
   //add portal event listener;
   //add
    window.onload=(function(){
      if(typeof callback==='function'){
           callback(portal);
      }
    });
   }).bind(this),portal, callback)
})


})(Application);