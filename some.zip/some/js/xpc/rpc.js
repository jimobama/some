if(!Application)var Application={};
if(!Application.http)Application.http={};

(function(http)
{
    var Rpc =Application.Extends(Application.events.Observable, (function(serverUrl){
      if(typeof serverUrl ==='string')
      	Object.defineProperties(this,{"url":serverUrl, writable:false, enumerable:false});
    }));
    Rpc.prototype.addField=(function(field){
     if(field instanceof Application.http.Field)
     	this.fields.push(field);
    });

    Rpc.prototype.request =(function(url){
     return new Promise((function(resolve, reject){
     	if(this.__isInProgress){
           cancelCurrentRequest,bind(this)();

     	}
     }).bind(this))

    });

    http.Rpc = Rpc;
  
})(Application.http);