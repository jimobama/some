if(!Application)var Application={};
if(!Application.http)Application.http={};

(function(http)
{
	var Field =(function(value, type){
      this.value =value;
      this.type  =type || "unknown";
	});
	/**
	Parse the value into the http value
	*/
   Fields.prototype.setValue =(function(value)
   {
     if(value){
     	this.value = value;
     }
   })
	Field.prototype.getValue =(function()
	{
		return this.value;
	});
	Field.prototype.getType=(function(){
      return this.type;
	});
	http.Field = Field;
})(Application.http);