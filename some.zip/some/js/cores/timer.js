

if(!Application) var Application ={};
if(!Application.utils)Application.utils={};

(function(utils){
var NUM_OF_ACTIVE_CONCURRENCE = NUM_OF_ACTIVE_CONCURRENCE || 0;
var ACTIVE_TIMER  = ACTIVE_TIMER || null;
var TIMERS  = [];
var PENDING = 0x01;
var RUNNING = 0x02;
var STOP    = 0x03;
var RESUME  = 0x04;
var KILLED  = 0x05;


/**
The function repeating called the user callback function util it returns true 
or the number of repeats reached.
@private
**/
var repeatCalling =(function(){	
    return  window.setInterval((function(){
    if(this.state===STOP || this.state===PENDING || this.state===KILLED){
    	this.kill(true);
    	return;
    } 
    if(this.force===true){
    	if(this.times >0){
    		this.repeatCount++;
    	}
      this.force =false;
    }
    //monitor the number of times to repeat the caller
    if(this.times > 0){
         if(this.times === this.repeatCount)
        	{
        	  this.kill(true);
        	}else
         		this.repeatCount++;
     }
    if(this.repeat !==false){ 
        ACTIVE_TIMER = this; 
    if(typeof this.callback !=='function')
   		this.kill();          	
    	this.repeat =  !this.callback.apply(null, this.callArgs);
    }else{
    	this.kill();
    }
   }).bind(this),this.interval)

})

/**
The function called the user callback method
@method

*/
var notRepeatCalling =(function(){
   return window.setTimeout((function(){
   	if(this.force===true) {this.kill();this.force=false};
   	if(this.state ===KILLED || this.state===STOP || this.state ===PENDING){
   		this.kill(true);
   	    return;
   	}
   	ACTIVE_TIMER = this;
   	if(typeof this.callback !=='function')
   		this.kill();
    this.callback.apply(null, this.callArgs);
    this.kill();   
   }).bind(this),this.interval)
})




/**
The timer class that act like a thread
@class
*/


var Timer =(function(interval,repeat, times){
   this.repeat =(repeat===true)?repeat:false;
   this.interval = (typeof interval ==='number')?parseInt(interval):0;
   this.id = null; 
   this.state=PENDING;
   this.times = (typeof times ==='number')?parseInt(times):0;
   this.repeatCount = 1;
   //create a new thread
   Object.defineProperties(this, {"threadID":{value:TIMERS.length,writable:false, enumerable:false}});
   TIMERS.push(this);
});

/**
 The function is the entry point for the timer 
 @method
 @param {Function} callback the function to call when the interval time is reached
 @param {varadic Arguments} args a varadic arguments that will be passed to the callback function when its called.
 @memberof Timer#
*/

Timer.prototype.run =(function(callback, ...args){
	if(this.state !=PENDING || this.state === KILLED){
		return
	};		
	this.callArgs         = args || this.callArgs;
	this.callback         = callback || this.callback;
	this.type= this.type || "no-repeat";
    ACTIVE_TIMER =this; 
    this.state = RUNNING;    
	if(this.repeat){		  	
	    this.type="repeat";  	
	  	this.id = repeatCalling.bind(this)();
	}else{
	  	this.id = notRepeatCalling.bind(this)();
	}	
});



Timer.prototype.reset =(function(count){
  this.repeatCount =1;
  this.times = (typeof count ==='number')?Math.abs(parseInt(count)):1;
});
/**
 The function call is used to force the callback timer to call its caller before the given time
 @method


*/

Timer.prototype.recall = (function(){
 if(this.callback && this.state === RUNNING){
 	this.force =true;
 	this.repeat = !(this.callback.apply(null, this.callArgs));
 }
})

Timer.prototype.stop =(function(){
	this.state = STOP;
});
Timer.prototype.resume =(function(){
	this.state = PENDING;
	this.run();	
});

Timer.prototype.kill =(function(keep){
  var keep =(typeof keep==='boolean')?keep:false;  
  if(this.id){
  	 if(this.type=='repeat')
  		 window.clearInterval(this.id);
  	 else
  	   window.clearTimeout(this.id);
  	if(!keep){
  		TIMERS.splice(this.threadID,1);
  		this.state = KILLED;
  		this.callback = null;
        this.callArgs = null;
        
  	}
  	Timer.CheckActive();
  }
  this.id       = null;
});


/**
Static method that will return the current active timer
 @method
 @memberof  Timer
*/
Timer.CurrentActive = (function(){
	return ACTIVE_TIMER;
})
/**
  Count the to active timers
 @method
 @memberof  Timer
*/
Timer.GetActiveTimerCount=(function(){
	var count=0;
	for(var i =0; i < TIMERS.length ; i++){
      var timer = TIMERS[i];
      if(timer.state ===RUNNING)
      	count++;
	}
	return count;
});


Timer.GetTimerCount=(function(){
	return TIMERS.length;
});

Timer.StopAll = (function(){		
   for(var i=0; i < TIMERS.length; i++){
   	  var thread = TIMERS[i];
   	  thread.stop();
   }
});

Timer.ResumeAll = (function(){
 for(var i=0; i < TIMERS.length; i++){
   	  var thread = TIMERS[i];
   	  thread.resume();
   }
});

Timer.KillAll = (function(){
 for(var i=0; i < TIMERS.length; i++){
   	  var thread = TIMERS[i];
   	  thread.kill();
   }
});

Timer.CheckActive =(function(){
	if(TIMERS.length <=0)
		ACTIVE_TIMER=null;
})

utils.Timer = Timer;
})(Application.utils);