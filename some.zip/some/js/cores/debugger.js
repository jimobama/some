
if(!Application)var Application ={};

(function(_global){

  var Debugger =(function(){
   

  });

   Debugger.debug = (function(message){
     var debug = console.debug || console.warn || console.log;
     var debug = debug.bind(console)(message);
   })

  //add server and console debugger
  _global.Debugger = Debugger;
	
})(Application)