
if(!Application)
	var Application ={};
if(!Application.components)
	Application.components ={};

(function(components){

var Component =Application.Extends (Application.events.Observer, function(){



})  
Component.prototype.dispose =(function(scope){

});
Component.prototype.invalidated =(function(scope){

});
Component.prototype.refresh =(function(scope){


});




components.IComponent = Component;
})(Application.components);