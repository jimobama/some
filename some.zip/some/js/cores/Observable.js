if(!Application) var Application={};
if(!Application.events)Application.events={};
(function(events){

/**
@class
*/
var Observable =Application.Extends(EventTarget, (function(){
   Object.defineProperties(this, {"observers":{value:[], "writable":false, "enumerable":false}});
}));
/**
  Add observer to the list of observers
  @method
*/
Observable.prototype.addObserver =(function(...observers){
    var timer = new Application.utils.Timer(0);
    timer.run((function(lists){
     for(var i=0; i < lists.length; i++){
     	var observer = lists[i];
     	if(observer instanceof Application.events.IObserver){
	    	if(!this.isObserverExists(observer)){
	          this.observers.push(observer);
	    	}
        }
     }
     return true;
    }).bind(this), Array.prototype.slice.call(observers));
});



/**
 Check if the observer already exists
*/
Observable.prototype.isObserverExists =(function(observer){
	if(observer && observer instanceof Application.events.IObserver){
      for(var i=0; i < this.observers.length; i++){
      	 var obser = this.observers[i];
      	 if(obser === observer){
      	 	return true;
      	 }
      }
     return false;
	}else return true;
});

Observable.prototype.removeObserver =(function(observer){
    var timer = new Application.utils.Timer(0,true,3);
    timer.run((function(observer){
     if(this.isObserverExists(observer))
     {
     	var isEquals=false;
     	for(var i=0; i < this.observers.length; i++){
			var obser = this.observers[i];
				if(obser.equals){
					if(obser.equals(observer))
                        isEquals = true;
					}else{
						if(obser === observer)
							isEquals = true;
					}
				if(isEquals){
					this.observers.splice(i,1);
					console.log("Removed")
					break;
					}
					
		}
	  return true; 
     }
    }).bind(this), observer);


});

Observable.prototype.notify=(function(observer,type, ...eventArgs){
 var timer = new Application.utils.Timer(1,true, 3);
 timer.run((function(observer,type, args, timer){ 
 	 var filter = observer.getEventFilter(); 	
 	 filter.match(type).then((function(isMatched){
 	 	if(isMatched){ 	 	
 	 	 var data = args;
 	 	 data.unshift(type);
 	 	 data.unshift(this); 	 	 
 	 	 observer.onNotify.apply(observer,  data); 
 	 	 timer.kill();
 	 	}
 	 }).bind(this));
 }).bind(this),observer, type, eventArgs, timer);	

});

Observable.prototype.notifyAll =(function(type, ...argument_list){
 var timer = new Application.utils.Timer(0);
 timer.run((function(type,list)
 {

 	var sendArgs = list;
    for(var i=0; i < this.observers.length; i++){
         var observer = this.observers[i];
         sendArgs.unshift(type);
         sendArgs.unshift(observer);
	 	 this.notify.apply(this, sendArgs);
	 	 sendArgs.shift();
	 	 sendArgs.shift();
	 }
 }).bind(this),type, argument_list);

});

Observable.prototype.countObserver =(function(){
  return this.observers.length;
})


events.Observable= Observable;
})(Application.events)