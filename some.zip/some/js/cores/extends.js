
if(!Application)var Application ={};

(function(_global){

/**
 Deep Inheritances in javascript
*/	
_global.Extends =(function(parent, construct){
	var construct = (typeof construct ==='function')?construct:(function(){});
	if(typeof parent !=='function') return construct;
	var subclass = construct;
    for(prop in parent){
    	subclass[prop]= parent[prop];
    }
	subclass.prototype = Object.create(parent.prototype);
	subclass.prototype.parent = parent; 
	subclass.prototype.super=(function(...args)
	{
	  if(this.parent)
     	   this.parent.apply(this, args);
	});
	return subclass;
});

})(Application);