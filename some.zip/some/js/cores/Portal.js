
/**
The parent module application 
@Module Application

**/
/**
**/
if(!Application)
     var Application={};

(function(_global)
{
 var components = components || {};
 var client     = client    || null;
 var caches     = caches    || {};
 var isExit     = isExit    || false;
 var isFault    = isFault   || false;


 var Portal = Application.Extends(Application.events.Observable, (function(client){
 	this.super();
    client = client;
 }));
 /**
 Private methods
 */
 var createView =(function(){
    if(!this)return null;
   var fragment = document.createDocumentFragment();
    var appDiv = document.createElement("div");
    if(appDiv){
    	appDiv.setAttribute("theme", "a");
    	appDiv.id="portal";
    }
    fragment.windoObject = appDiv;
    fragment.appendChild(appDiv);
   return fragment;
 });


 Portal.prototype.onViewCreate =(function(view){
  return view;
 });

 Portal.prototype.getClient =(function(){
 	 return client;
 });

Portal.prototype.render =(function(){
   //create the base element of the portal
   var fragment = createView.bind(this)();
   if(fragment){   	 
   var view = this.onViewCreate(fragment.windoObject);
   if(view instanceof HTMLElement){
   	 Object.defineProperties(this, {"view":{value:view, writable:false, enumerable:false}});
   }
   document.body.appendChild(fragment);
   this.notifyAll("onCreate", this);
  }
})

_global.Portal = Portal;
})(Application);