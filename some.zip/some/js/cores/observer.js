
if(!Application)var Application={};
if(!Application.events)Application.events={};

(function(_global){

	var Observer =(function(){
		//this will filter events that the observer want to listen to
	   this.eventFilter =  new Application.events.EventFilter();   
	})

	Observer.prototype.getEventFilter =(function(){
	   return  this.eventFilter;
	});
	Observer.prototype.filter=(function(type){
		this.eventFilter.filter(type);
       return this;
	})
	Observer.prototype.setEventFilter =(function(filter){
		if(filter instanceof Application.events.EventFilter)
	      this.eventFilter = filter;
	  return this;
	});

	/**
	The function is called when an event has occur 
	@method
	@param {sender}:Observable the object that send the event
	@memberof Observer#
	**/
	Observer.prototype.onNotify =(function(sender, ...eventArgs){
	 	var timer = new Application.utils.Timer(0);
	 	timer.run((function(sender , args){
	 		throw new Error("@Observer.prototype.onNotify: is an abstract method and need to be implemetated with arguments ["+args+"]");
	 	}).bind(this), sender,eventArgs);
	 	
	 });


	_global.IObserver = Observer;

})(Application.events)