/**
Client base client for all portal application.
Each clients is identify by their ip, mac and os operating system and models and locations

*/
(function(){
 var Client =(function(app){
   	Object.defineProperties(this, {"application":{"value":app,"writable":false, "enumerable":false}}); 
 });

 //just a tag to make use know which class the Class Object belongs to
 Client._ ="client";

Client.prototype.getApplication=(function(){
   return this.application;
});

Client.prototype.getInformation =(function(){
   var clientInfo = new ClientInfo("","","");

   return clientInfo;
})

/**The function called the register class to register the information of the application
@method
@memberof Client
*/
 Client.prototype.register =(function(){
  var app = this.getApplication();
  app.registerClient(this, this.getInformation());
  app.log("Register Client:","Registering new client to the server");
  return this;
 })
Application.Client = Client;
Application.Portal.UseClient(Client,"amino");

})();