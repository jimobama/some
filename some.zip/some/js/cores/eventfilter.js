/**
 The module class filter only the event the observer want to listen too
*/
if(!Application)var Application={};
if(!Application.events)Application.events={};

(function(events){
	/**
	 The filter class filter only the object need for its host
		@class
	**/
	
	var EventFilter = (function(){
       Object.defineProperties(this, {"typenames":{value:[], "writable":false, "enumerable":false}});
       
	});

/**
 The method will match the event argument and return a promised
 @method
 @param {Object} eventArgs an object with {type:eventName, ...}
**/
	EventFilter.prototype.match =(function(eventtype){
	 return new Promise((function(resolve, reject)
	 {
	 	var temType =  (typeof eventtype ==='string')?eventtype.toLowerCase():eventtype;
	    try{
	      for(var i=0; i < this.typenames.length;  i++){
	         var event = this.typenames[i];
	         evntType  =(typeof event.type ==='string')?event.type.toLowerCase():event.type;
	      	 if(evntType === temType){
               resolve(true);
              break;
	      	 }
	      }//for
	     resolve(false);
	    }catch(error){
	      reject(error);
	    }
	 }).bind(this));
  });

/**
 The function all the Observer to set the event type to listen to.
*/
EventFilter.prototype.filter =(function(eventtype){
 var type = (typeof eventtype==='string')?eventtype.toLowerCase():eventtype;
 this.match({"type":type}).then((function(isFound){

    if(!isFound){
            this.typenames.push({"type":type});
            return;
         }
       }).bind(this));
});

EventFilter.prototype.filters =(function(eventtypes){
   	if(typeof eventtypes!=='object') return;
    for(var prop in eventtypes){
    	var type = (typeof eventtypes[prop]==='string')?eventtypes[prop]:eventtypes[prop];
        this.filter(type);
    }
});


//global
	events.EventFilter = EventFilter;

})(Application.events)